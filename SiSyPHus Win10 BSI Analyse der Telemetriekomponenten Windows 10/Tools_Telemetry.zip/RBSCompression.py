#!/usr/bin/env python3
# coding: utf-8
import zlib
import sys

d = zlib.decompressobj(wbits=-zlib.MAX_WBITS)

with open(str(sys.argv[1]), 'rb') as fp:

    fp.seek(0x52)

    for chunk in iter(lambda: fp.read(1024), b''):
        try:
            sys.stdout.buffer.write(d.decompress(chunk))
        except Exception as e:
            print(e)
            break