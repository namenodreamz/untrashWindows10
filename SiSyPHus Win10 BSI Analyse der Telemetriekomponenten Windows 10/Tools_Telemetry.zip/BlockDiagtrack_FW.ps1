# Besitzer der Datei aendern
$Account = New-Object -TypeName System.Security.Principal.NTAccount -ArgumentList 'VORDEFINIERT\Administratoren';
$ACL = $null
$ACL = Get-Acl -Path C:\Windows\System32\svchost.exe
$ACL.SetOwner($Account)
Set-Acl -Path C:\Windows\System32\svchost.exe -AclObject $ACL
# Abfrage der Access Control Liste
$ACL = $null
$ACL = Get-Acl C:\Windows\System32\svchost.exe
# Zugriffsrechte setzen
$Ar = New-Object System.Security.AccessControl.FileSystemAccessRule($Account, "Write", "Allow")
$ACL.SetAccessRule($Ar)
Set-Acl C:\Windows\System32\svchost.exe $ACL
# Wechsle in Zielverzeichnis
Set-Location -Path C:\Windows\System32\
# Erstellung Hardlink
New-Item -ItemType hardlink -Name hard.exe -Value .\svchost.exe
# Anpassung der Registry
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\DiagTrack" -Name "ImagePath" -Value "%SystemRoot%\System32\hard.exe -k utcsvc"
# Hinzufuegen der Firewall Regel
New-NetFirewallRule -DisplayName "Block_Diagtrack" -Name "Block_Diagtrack" -Direction Outbound -Program "%SystemRoot%\System32\hard.exe"
